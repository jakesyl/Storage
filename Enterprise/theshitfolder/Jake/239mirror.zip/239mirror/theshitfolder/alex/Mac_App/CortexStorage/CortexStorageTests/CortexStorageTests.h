//
//  CortexStorageTests.h
//  CortexStorageTests
//
//  Created by Alex Parson on 7/18/14.
//  Copyright (c) 2014 Alex Parson. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CortexStorageTests : SenTestCase

@end
