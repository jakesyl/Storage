//
//  CortexStorageTests.m
//  CortexStorageTests
//
//  Created by Alex Parson on 7/18/14.
//  Copyright (c) 2014 Alex Parson. All rights reserved.
//

#import "CortexStorageTests.h"

@implementation CortexStorageTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in CortexStorageTests");
}

@end
