cortexstorage
=============

A python storage application
