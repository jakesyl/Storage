#
#  FilteringController
#

from PyObjCTools import AppHelper
import FilteringControllerDocument
import FilteringArrayController

AppHelper.runEventLoop()
