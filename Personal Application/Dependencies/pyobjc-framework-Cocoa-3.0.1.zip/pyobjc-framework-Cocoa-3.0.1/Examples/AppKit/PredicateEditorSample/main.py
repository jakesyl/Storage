from PyObjCTools import AppHelper

import CaseInsensitivePredicateTemplate
import MyWindowController

AppHelper.runEventLoop()
