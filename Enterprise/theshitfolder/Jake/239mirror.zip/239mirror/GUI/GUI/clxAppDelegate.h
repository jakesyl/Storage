//
//  clxAppDelegate.h
//  GUI
//
//  Created by Jake Sylvestre on 7/24/14.
//  Copyright (c) 2014 Jake Sylvestre. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface clxAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
