THIS IS THE INSTALL ORDER, DO NOT INSTALL OUT OF ORDER:
1.ecdsa
2. pyobjc-core
3. pyobjc-framework-Cocoa-3.0.1
4. party
5.pycrypto
6.pyscopg2
7.paramiko
8.pysftp