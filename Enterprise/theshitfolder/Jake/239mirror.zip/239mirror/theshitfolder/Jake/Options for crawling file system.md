os.walk: 
* http://pymotw.com/2/os/index.html#walking-a-directory-tree

os.expand user:
* https://docs.python.org/2/library/os.path.html 

os.path
* https://docs.python.org/2/library/os.path.htmlst