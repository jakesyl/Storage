//
//  clxAppDelegate.m
//  GUI
//
//  Created by Jake Sylvestre on 7/24/14.
//  Copyright (c) 2014 Jake Sylvestre. All rights reserved.
//

#import "clxAppDelegate.h"

@implementation clxAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
