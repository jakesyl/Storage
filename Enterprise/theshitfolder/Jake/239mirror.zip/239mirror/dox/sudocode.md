 Uploading
* How are you getting this data?
* cluster analysis
*Log in Local Database - SQLite 3
* database types:
multi
frequency
times
single 
time 
type
other shit
final packaging
Jake - 
Identify dependencies 
crawl code
Find audio/video
Extensions
failed upload handling
Onpause() kinda thing
Alex/Jake
Streaming
Gui
