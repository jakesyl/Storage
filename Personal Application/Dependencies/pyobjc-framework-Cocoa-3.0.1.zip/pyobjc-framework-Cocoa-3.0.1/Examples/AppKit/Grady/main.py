from PyObjCTools import AppHelper

import AppDelegate
import MyBaseGradientView
import MyBezierGradientView
import MyRectGradientView
import MyWindowController

AppHelper.runEventLoop()
