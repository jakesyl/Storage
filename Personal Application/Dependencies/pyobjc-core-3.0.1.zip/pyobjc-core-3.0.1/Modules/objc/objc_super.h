#ifndef PyObjC_SUPER_H
#define PyObjC_SUPER_H

#ifndef Py_HAVE_LOCAL_LOOKUP

extern PyTypeObject PyObjCSuper_Type;

#endif /* !Py_HAVE_LOCAL_LOOKUP */

#endif /* PyObjC_SUPER_H */
