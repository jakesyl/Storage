Push updates: https://docs.google.com/document/d/1vQ5PuAkB5kjfE6xfUZRhmdQ1bEsMteGo5Vo7eJn2nKc/edit
Cloned from: https://docs.google.com/document/d/1vQ5PuAkB5kjfE6xfUZRhmdQ1bEsMteGo5Vo7eJn2nKc/edit

Cluster Formation
ignore x86 and x64 Directories
Dependencies
Finds lone audio/video
word docs, random code, images etc
when part of the cluster
http://arxiv.org/pdf/1303.0598.pdf
Server shit
Audio/Video Streaming: Python/Open Source think streaming kit: https://github.com/jakesyl/cortexstorage/settings/collaboration
